/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtin_export.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jderachi <jderachi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/05 11:39:55 by jderachi          #+#    #+#             */
/*   Updated: 2026/01/05 14:04:04 by jderachi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../env/env.h"
#include "../inc/minishell.h"
#include "builtins.h"
#include <sys/wait.h>

// char	*extract_vars(const char *str)
// {
// 	int	i;
// 	int	len;

// 	if (!str)
// 		return (NULL);

// 	i = 0;
// 	while (str[i] && str[i] != '$')
// 		i++;
// 	if (str[i] != '$')
// 		return (NULL);

// 	i++;
// 	len = 0;
// 	while (str[i + len] && (ft_isalnum(str[i + len]) || str[i + len] == '_'))
// 		len++;

// 	return (ft_substr(str, i, len));
// }

// void	echo_print_word(char *word, t_env *env)
// {
// 	int		pos;
// 	char	*var;
// 	char	*value;

// 	var = extract_vars(word);
// 	if (!var)
// 	{
// 		printf("%s", word);
// 		return ;
// 	}
// 	value = get_env_value(env, var);
// 	pos = 0;
// 	while (word[pos] && word[pos] != '$')
// 		pos++;
// 	pos++;
// 	while (word[pos] && (ft_isalnum(word[pos]) || word[pos] == '_'))
// 		pos++;
// 	if (value)
// 		printf("%s", value);
// 	printf("%s", word + pos);
// 	free(var);
// }

int	builtin_export(t_node *node, t_env *env)
{
	int		i;
	int		j;
	int 	k;
	char	**array;
	char	**export;
	char	*value;

	printf("builtin_export\n");
	i = 1;
	while (node->cmd[i])
	{
		array = ft_split(node->cmd[i], ' ');
		j = 0;
		while (array[j])
		{
			printf("%s", array[j]);
			if (ft_strchr(array[j], '='))
			{
				printf(" > export found");
				export = ft_split(array[j], '=');
				printf(" > name = %s", export[0]);
				value = ft_strdup("");
				k = 1;
				while (export[k])
				{
					value = ft_strjoin(value, export[k++]);
				}
				printf(" > name = %s", export[0]);

				add_env(&env, export[0], value);
			}
			printf("\n");
			j++;
		}
		print_env_list(env);
		free_array(array);
		i++;
	}
	printf("\n");
	return (0);
}
